BasicCardsOOP (modified version of Card Game Starter Kit)

This project will deal 52 cards (animation) as 4 rows of 13 cards.

Features:
Card animation, deal 52 cards
Shuffle cards and deal cards to table
Show/Hide cards face
Clear table
Sound


Visual Studio 2022

-----

BlackJack Game from Microsoft

Card Game Starter Kit - VCS

This C# Starter Kit is a complete BlackJack card game. The project comes ready to compile and run, and it's easy to customize with only a little extra C# programming. The documentation contains a list of some customizations you might make. You are also free to use the source code as the basis for your own card game projects, and share your work with others or upload it to the Internet.

https://marketplace.visualstudio.com/items?itemName=VisualStudioProductTeam.CardGameStarterKit-VCS-3882

Works with
Visual Studio 2010
Resources Copy ID

More Info
Version 	1.1 	
Released on 	2/11/2010, 1:58:38 AM 	
Last updated 	2/11/2010, 2:57:40 AM
